// Check if notifications are supported
if (window["Notification"]) {
    // Request permission
    Notification.requestPermission();
}
